import React from 'react'

import {
    StatusBar,
    Text,
    View
} from 'react-native'

import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'

import {
  faImage
} from '@fortawesome/free-regular-svg-icons'

import style from './StyleSheet'

export default class Toolbar extends React.Component {
    render() {
        return (
          <View style={ style.container }>
                
            <StatusBar backgroundColor='#ED145B' />
      
            <FontAwesomeIcon
              color='#ED145B'
              icon={ faImage }
              size={ 32 }
              style={ style.icone } />
    
              <Text style={ style.texto }>
                FIAPGram
              </Text>      
          </View>
        )
    }
}